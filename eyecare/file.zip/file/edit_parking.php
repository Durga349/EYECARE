
<?php include "includes/header.php";

$doc_sql = "select * from dropdown_lists order by id asc";
$doc_data = $crud->getData($doc_sql);

 
 $randid = $_GET['randomId'];
 $parking_qry = "select * from parking where randomId = '".$randid."'";
//exit;

$parking_data = $crud->getData($parking_qry); 
 
?> 
 
 
  <?php include "includes/navbar.php"; ?> 
 
  <?php include "includes/sidebar.php"; ?> 
   
<style> 
    .error{ 
      color: red; 
    } 
  </style> 
 
  <div class="mobile-menu-overlay"></div> 
 
  <div class="main-container"> 
    <div class="pd-ltr-20 xs-pd-20-10"> 
      <div class="min-height-200px"> 
        <div class="page-header"> 
          <div class="row"> 
            <div class="col-md-9 col-sm-12"> 
              <div class="title"> 
                <?php if($_REQUEST['type'] == 'view' ){ ?> 
                <h4>View Form Parking</h4> 
                <?php } ?> 
              </div> 
               
            </div> 
          <div class="col-md-3 col-sm-12"> 
              <nav aria-label="breadcrumb" role="navigation"> 
                <ol class="breadcrumb"> 
                  <li class="breadcrumb-item"><a href="index.html">Home</a></li> 
                  <?php if($_REQUEST['type'] == 'view' ){ ?> 
                  <li class="breadcrumb-item active" aria-current="page">View Form Parking</li> 
                <?php } ?> 
                </ol> 
              </nav> 
            </div> 
          </div> 
        </div> 
        <!-- Default Basic Forms Start --> 
        <div class="pd-20 card-box mb-30"> 
          <div class="clearfix"> 
            <div class="pull-left"> 
              <?php if($_REQUEST['type'] == 'edit' ){ ?> 
              <h4 class="text-blue h4">Edit Form Parking</h4> 
              <?php } ?>

               <?php if($_REQUEST['type'] == 'view' ){ ?> 
              <h4 class="text-blue h4">View Form Parking</h4> 
              <?php } ?><br> 
              <!-- <p class="mb-30">All bootstrap element classies</p> --> 
            </div> 
             
          </div>
<?php if($_REQUEST['type'] == 'view' ){ ?>  
          <form method="post" id="addformpage" name="addformpage" enctype="multipart/form-data">
            
              <div class="row">
                <div class="col-md-6">
                  <label>Document No</label>
                  <input type="text" name="document_no" class="form-control" value="<?php echo $parking_data[0]['document_no'] ?>" readonly>               
                  
                </div>            
                <div class="col-md-6">
                  <label>Department</label>
                  <input type="text" name="department" class="form-control" value="<?php echo $parking_data[0]['department'] ?>" readonly> 
               
                  
                </div>        
            </div>            
            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Gate Entry Type  </label>
                  <input type="text" name="gate_ent_type" class="form-control" value="<?php echo $parking_data[0]['gate_ent_type'] ?>" readonly>         
                  
                </div>

                <div class="col-md-6">
                  <label>Gate In Date </label>
                  <input type="date" name="gate_in_date" id="gate_in_date" class="form-control" value="<?php echo $parking_data[0]['gate_in_date'] ?>" readonly>
                  
                </div>              
            </div>
            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Gate Out Date</label>
                  <input type="date" name="gate_out_date" id="gate_out_date" class="form-control" value="<?php echo $parking_data[0]['gate_out_date'] ?>"readonly>
                </div>            
                <div class="col-md-6">
                  <label>Gate Status</label>
                  <input type="text" name="gate_status" class="form-control" value="<?php echo $parking_data[0]['gate_status'] ?>" readonly>                 
                  
                </div>      
            </div>
            <div class="row pt-2">
                            
                <div class="col-md-6">
                  <label>Date</label>
                  <input type="date" name="date" id="date" class="form-control" value="<?php echo $parking_data[0]['date'] ?>" readonly>
                </div>      
            </div>
            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Gate</label>
                  <input type="text" name="gate" class="form-control" value="<?php echo $parking_data[0]['gate'] ?>" readonly>             
          
                </div>            
                <div class="col-md-6">
                  <label>Vehicle</label>
                  <input type="text" name="vehicle" class="form-control" value="<?php echo $parking_data[0]['vehicle'] ?>" readonly>                 
                </div>      
            </div>  
            <div class="row pt-2">
                <div class="col-md-6">
                  <label>GateIn</label>
                  <input type="time" name="gate_in_time" id="gate_in_time" class="form-control" value="<?php echo $parking_data[0]['gate_in_time'] ?>" readonly> 
                </div>            
                <div class="col-md-6">
                  <label>Gateout</label>
                  <input type="time" name="gate_out_time" id="gate_out_time" class="form-control" value="<?php echo $parking_data[0]['gate_out_time'] ?>"readonly>
                </div>      
            </div>    
            <div class="row pt-2">
              <div class="col-md-6">
                  <label>Narration</label>
                  
                  <textarea class="form-control" name="narration" id="narration"><?php echo $parking_data[0]['narration'] ?></textarea>
                </div>
                <!-- <div class="col-md-6">
                  <label>VehiclePhoto</label>
                  <input type="file" name="vehiclePhoto" id="vehiclePhoto" class="form-control">
                </div>
 -->
                  <div class="col-md-6">              
                        <label  for="exampleInputEmail1">Vehicle Photo
                          <!-- <span class="star">*</span> --></label>
                          <img id="previewImg" alt="Uploaded Image Preview" width="90px;" height="80px;"  style="display: none;"/>
                           <img src="<?php echo $parking_data[0]['vehi_photo'];?>" width="100px;" height="100px;">                  
                        </div>

                      
            </div>
            <div class="row pt-2">
              <div class="col-md-12">
              <input type="button" name="cancel" id="cancel" class="btn btn-danger float-left" value="Cancel" onclick="location.href = 'manageparking.php'">
              <input type="submit" name="submit" id="submit" class="btn btn-primary float-right" value="Submit">
              </div>
            </div>
            
            
          </form>
<?php } ?>


<?php if($_REQUEST['type'] == 'edit' ){ ?>
  <form method="post" id="addformpage" name="addformpage" enctype="multipart/form-data">
            
              <div class="row">
                <div class="col-md-6">
                  <label>Document No</label>
                  <select   class="custom-select col-12" name="document_no" id="document_no" class="form-control">                  
                  <?php foreach($doc_data as $value){ ?>  
                     <option value="<?php echo $value['id']?>" <?php if($value['id'] == $parking_data[0]['document_no']){echo "selected";}?>><?php echo $value['document_no']?></option>
                     <?php }?>  
                </select>
                  
                </div>            
                <div class="col-md-6">
                  <label>Department</label> 
                <select class="custom-select col-12" name="department" id="department" class="form-control">
                  <option value="">--Select--</option>
                  <?php foreach($doc_data as $value){ ?>  
                     <option value="<?php echo $value['id']?>" <?php if($value['id'] == $parking_data[0]['department']){echo "selected";}?>><?php echo $value['department']?></option>
                     <?php }?>                 
                    
                </select>
                  
                </div>        
            </div>            
            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Gate Entry Type  </label>
                  <select class="custom-select col-12" name="gate_ent_type" id="gate_ent_type" class="form-control">
                    
                  <option value="">--Select--</option>
                  <?php foreach($doc_data as $value){ ?>
                  <option value="<?php echo $value['id']?>" <?php if($value['id'] == $parking_data[0]['gate_ent_type']){echo "selected";}?>><?php echo $value['gate_ent_type']?></option>
                     <?php }?> 
                   
                </select>
                  
                </div>

                <div class="col-md-6">
                  <label>Gate In Date </label>
                  <input type="date" name="gate_in_date" id="gate_in_date" class="form-control" value="<?php echo $parking_data[0]['gate_in_date'] ?>">
                  
                </div>              
            </div>
            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Gate Out Date</label>
                  <input type="date" name="gate_out_date" id="gate_out_date" class="form-control" value="<?php echo $parking_data[0]['gate_out_date'] ?>">
                </div>            
                <div class="col-md-6">
                  <label>Gate Status</label>
                  <select class="custom-select col-12" name="gate_status" id="gate_status" class="form-control">
                  <option value="">--Select--</option>
                  <?php foreach($doc_data as $value){ ?>
                  <option value="<?php echo $value['id']?>" <?php if($value['id'] == $parking_data[0]['gate_status']){echo "selected";}?>><?php echo $value['gate_status']?></option>
                     <?php }?> 
              
                  
                </select>
                  
                </div>      
            </div>
            <div class="row pt-2">
                            
                <div class="col-md-6">
                  <label>Date</label>
                  <input type="date" name="date" id="date" class="form-control" value="<?php echo $parking_data[0]['date'] ?>">
                </div>      
            </div>
            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Gate</label>
                  <select class="custom-select col-12" name="gate" id="gate" class="form-control">
                  <option value="">--Select--</option>
                  <?php foreach($doc_data as $value){ ?>
                  <option value="<?php echo $value['id']?>" <?php if($value['id'] == $parking_data[0]['gate']){echo "selected";}?>><?php echo $value['gate']?></option>
                     <?php }?> 

                  </select>
                  
          
                </div>            
                <div class="col-md-6">
                  <label>Vehicle</label>
                  <select class="custom-select col-12" name="vehicle" id="vehicle" class="form-control">
                  <option value="">--Select--</option>
                  <?php foreach($doc_data as $value){ ?>
                   <option value="<?php echo $value['id']?>" <?php if($value['id'] == $parking_data[0]['vehicle']){echo "selected";}?>><?php echo $value['vehicle']?></option>
                     <?php }?> 
                  
                </select>
                </div>      
            </div>  
            <div class="row pt-2">
                <div class="col-md-6">
                  <label>GateIn</label>
                  <input type="time" name="gate_in_time" id="gate_in_time" class="form-control" value="<?php echo $parking_data[0]['gate_in_time'] ?>">
                </div>            
                <div class="col-md-6">
                  <label>Gateout</label>
                  <input type="time" name="gate_out_time" id="gate_out_time" class="form-control" value="<?php echo $parking_data[0]['gate_out_time'] ?>">
                </div>      
            </div>    
            <div class="row pt-2">
              <div class="col-md-6">
                  <label>Narration</label>
                  
                  <textarea class="form-control" name="narration" id="narration"><?php echo $parking_data[0]['narration'] ?></textarea>
                </div>
                
                  <div class="col-md-6">              
                        <label  for="exampleInputEmail1">Vehicle Photo
                          <!-- <span class="star">*</span> --></label>
                          <input type="hidden" id="edit_extimage" name="edit_extimage" class="form-control" value="<?php echo $parking_data[0]['vehi_photo'];?>">
                          <input type="file" class="form-control" name="vehi_photo" id="vehi_photo" title="Please upload photo (jpg, jpeg, png)" value="" onchange="return fileValidation(this.id,'previewImg')">
                         <img src="<?php echo $parking_data[0]['vehi_photo'];?>" width="100px;" height="100px;">
                            <img id="previewImg" alt="Upload Image Preview" width="90px" height="80px" style="display: none;"/>                      
                        </div>

                      
            </div>
            <div class="row pt-2">
              <div class="col-md-12">
                <input type="hidden" name="hdn_id" id="hdn_id" value="<?php echo $parking_data[0]['randomId'] ?>">
              <input type="button" name="cancel" id="cancel" class="btn btn-danger float-left" value="Cancel" onclick="location.href = 'manageparking.php'">
              <input type="submit" name="submit" id="submit" class="btn btn-primary float-right" value="Update">
              </div>
            </div>
            
            
          </form>



<?php } ?> 



           
        </div> 
        <!-- Default Basic Forms End --> 
 
         
      </div> 
       
    </div> 
  </div> 
  <!-- Footer --> 
      <?php include "includes/footer.php"; ?>
      <script type="text/javascript" src="js/editParking.js"></script> 
 
