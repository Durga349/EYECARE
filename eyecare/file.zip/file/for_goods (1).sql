-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2022 at 03:36 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `focus`
--

-- --------------------------------------------------------

--
-- Table structure for table `for_goods`
--

CREATE TABLE `for_goods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `document_no` varchar(20) NOT NULL,
  `department` varchar(20) NOT NULL,
  `flow_classify` varchar(20) NOT NULL,
  `gate_ent_type` varchar(20) NOT NULL,
  `weighment_type` varchar(20) NOT NULL,
  `material_trans` varchar(20) NOT NULL,
  `agent` varchar(50) NOT NULL,
  `weighment_req` varchar(20) NOT NULL,
  `vendor_name` varchar(20) NOT NULL,
  `gate_in_date` varchar(20) NOT NULL,
  `gate_out_date` varchar(20) NOT NULL,
  `gate_status` varchar(20) NOT NULL,
  `narration` text NOT NULL,
  `date` varchar(20) NOT NULL,
  `gate` varchar(20) NOT NULL,
  `weigh_bridge` varchar(20) NOT NULL,
  `weighing_type` varchar(20) NOT NULL,
  `material_type` varchar(20) NOT NULL,
  `vehicle` varchar(20) NOT NULL,
  `outside_vehi` varchar(20) NOT NULL,
  `ven_name_village` varchar(50) NOT NULL,
  `gate_in_time` varchar(20) NOT NULL,
  `gate_out_time` varchar(20) NOT NULL,
  `scanner_time` varchar(20) NOT NULL,
  `vehi_photo` varchar(100) NOT NULL,
  `randomId` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `for_goods`
--

INSERT INTO `for_goods` (`id`, `document_no`, `department`, `flow_classify`, `gate_ent_type`, `weighment_type`, `material_trans`, `agent`, `weighment_req`, `vendor_name`, `gate_in_date`, `gate_out_date`, `gate_status`, `narration`, `date`, `gate`, `weigh_bridge`, `weighing_type`, `material_type`, `vehicle`, `outside_vehi`, `ven_name_village`, `gate_in_time`, `gate_out_time`, `scanner_time`, `vehi_photo`, `randomId`, `created_at`, `status`) VALUES
(2, '2', '2', '2', '2', '2', '2', '2', '2', '2', '2022-09-23', '2022-09-24', '2', 'Kakinada', '2022-09-24', '2', '2', '2', '2', '2', 'Lorry', '2', '14:32', '16:32', '16:32', 'pictures/vehi_photo_63298c0895.jpg', '632981e215', '2022-09-20 09:03:30', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `for_goods`
--
ALTER TABLE `for_goods`
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `for_goods`
--
ALTER TABLE `for_goods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
