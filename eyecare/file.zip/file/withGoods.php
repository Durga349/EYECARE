<?php include "includes/header.php"; 
$doc_sql = "select * from dropdown_lists order by id asc";
$doc_data = $crud->getData($doc_sql);
?>
 <style>
    .error{
      color: red;
    }
  </style>



	<?php include "includes/navbar.php"; ?>

	<?php include "includes/sidebar.php"; ?>
	


	<div class="mobile-menu-overlay"></div>

	<div class="main-container ">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-9 col-sm-12">
							<div class="title">
								<h4>Form With Goods</h4>
							</div>
							
						</div>
						<div class="col-md-3 col-sm-12">
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.html">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Form With Goods</li>
								</ol>
							</nav>							
						</div>
						
					</div>
				</div>
				<!-- Default Basic Forms Start -->
				<div class="pd-20 card-box mb-30">
					<div class="clearfix">
						<div class="pull-left">
							<h4 class="text-blue h4">Form With Goods</h4><br>
							<!-- <p class="mb-30">All bootstrap element classies</p> -->
						</div>						
					</div>
				<form method="post" name="withGoods" id="withGoods" enctype="multipart/form-data"  autocomplete="off">
							<div class="row">
								<div class="col-md-6">
									<label>Document No.</label>
									<select name="document_no" id="document_no" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	 
										<option value="<?php echo $value['id'] ?>"><?php echo $value['document_no'] ?></option>
										<?php }?>		
									</select>									
								</div>
								
						
								<div class="col-md-6">
									<label>Department</label>
									<select name="department" id="department" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	 
										<option value="<?php echo $value['id'] ?>"><?php echo $value['department'] ?></option>
										<?php }?>	
									</select>									
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Flow Calssify</label>
									<select name="flow_classify" id="flow_classify" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	 
										<option value="<?php echo $value['id'] ?>"><?php echo $value['flow_classify'] ?></option>
										<?php }?>	
									</select>									
								</div>
								
						
								<div class="col-md-6">
									<label>Gate Entry Type</label>
									<select name="gate_ent_type" id="gate_ent_type" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	 
										<option value="<?php echo $value['id'] ?>"><?php echo $value['gate_ent_type'] ?></option>
										<?php }?>	
									</select>									
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Weighment Type</label>
									<select name="weighment_type" id="weighment_type" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	 
										<option value="<?php echo $value['id'] ?>"><?php echo $value['weighment_type'] ?></option>
										<?php }?>	
									</select>									
								</div>
								
						
								<div class="col-md-6">
									<label>Material Transaction</label>
									<select name="material_trans" id="material_trans" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	 
										<option value="<?php echo $value['id'] ?>"><?php echo $value['material_trans'] ?></option>
										<?php }?>
									</select>									
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Agent</label>
									<select name="agent" id="agent" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	 
										<option value="<?php echo $value['id'] ?>"><?php echo $value['agent'] ?></option>
										<?php }?>	
									</select>									
								</div>
								
						
								<div class="col-md-6">
									<label>Is Weighment Required</label>
									<select name="weighment_req" id="weighment_req" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	 
										<option value="<?php echo $value['id'] ?>"><?php echo $value['weighment_req'] ?></option>
										<?php }?>	
									</select>									
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Vendor Name</label>
									<select name="vendor_name" id="vendor_name" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	 
										<option value="<?php echo $value['id'] ?>"><?php echo $value['vendor_name'] ?></option>
										<?php }?>	
									</select>									
								</div>

								

								<div class="col-md-6">
									<label>Gate Status</label>
									<select name="gate_status" id="gate_status" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	 
										<option value="<?php echo $value['id'] ?>"><?php echo $value['gate_status'] ?></option>
										<?php }?>
									</select>									
								</div>
								
						
														
						</div>

						<div class="row pt-2">

							<div class="col-md-6">
									<label>Gate In Date</label>
									<input type="date" name="gate_in_date" id="gate_in_date" class="form-control">			
								</div>
								<div class="col-md-6">
									<label>Gate Out Date</label>
									<input type="date" name="gate_out_date" id="gate_out_date" class="form-control">			
								</div>												
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Bill Reference No.</label>
									<input type="text" name="bill_ref_no" id="bill_ref_no" class="form-control">						
								</div>
								
						
								<div class="col-md-6">
									<label>Date</label>
									<input type="date" name="date" id="date" class="form-control">								
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Gate</label>
									<select name="gate" id="gate" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	 
										<option value="<?php echo $value['id'] ?>"><?php echo $value['gate'] ?></option>
										<?php }?>	
									</select>									
								</div>
								
						
								<div class="col-md-6">
									<label>Weigh Bridge</label>
									<select name="weigh_bridge" id="weigh_bridge" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	 
										<option value="<?php echo $value['id'] ?>"><?php echo $value['weigh_bridge'] ?></option>
										<?php }?>	
									</select>									
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Weighing Type</label>
									<select name="weighing_type" id="weighing_type" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	 
										<option value="<?php echo $value['id'] ?>"><?php echo $value['weighing_type'] ?></option>
										<?php }?>
									</select>									
								</div>
								
						
								<div class="col-md-6">
									<label>Material Type</label>
									<select name="material_type" id="material_type" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	 
										<option value="<?php echo $value['id'] ?>"><?php echo $value['material_type'] ?></option>
										<?php }?>	
									</select>									
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Vehicle</label>
									<select name="vehicle" id="vehicle" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	 
										<option value="<?php echo $value['id'] ?>"><?php echo $value['vehicle'] ?></option>
										<?php }?>	
									</select>									
								</div>
								
						
								<div class="col-md-6">
									<label>Outside Vehicle</label>
									<input type="text" name="outside_vehi" id="outside_vehi" class="form-control">				
								</div>						
						</div>

						<div class="row pt-2">						
						
								<div class="col-md-6">
									<label>Gate In</label>
									<input type="time" name="gate_in_time" id="gate_in_time" class="form-control">				
								</div>	

								<div class="col-md-6">
									<label>Gate Out</label>
									<input type="time" name="gate_out_time" id="gate_out_time" class="form-control">			
								</div>					
						</div>

						<div class="row pt-2">					
								
						
								<div class="col-md-6">
									<label>Scanner Time</label>
									<input type="time" name="scanner_time" id="scanner_time" class="form-control">				
								</div>	

								<div class="col-md-6">
									<label>Vendor Name in Village</label>
									<select name="ven_name_village" id="ven_name_village" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	 
										<option value="<?php echo $value['id'] ?>"><?php echo $value['ven_name_village'] ?></option>
										<?php }?>	
									</select>									
								</div>					
						</div>

						<div class="row pt-2">

							<div class="col-md-6">
									<label>Bill Date</label>
									<input type="date" name="bill_date" id="bill_date" class="form-control">							
								</div>

								<div class="col-md-6">
									<label>Bill Reference No.</label>
									<input type="text" name="bill_date_ref" id="bill_date_ref" class="form-control">							
								</div>					 						
						</div>

						<div class="row pt-2">

							<div class="col-md-6">
									<label>Narration</label>
									<textarea name="narration" id="narration" class="form-control"></textarea>							
								</div>

								<div class="col-md-6">              
				                <label  for="exampleInputEmail1">Vehicle Photo
				                  <!-- <span class="star">*</span> --></label>
				                  <input type="file" class="form-control" name="vehi_photo" id="vehi_photo" title="Please upload photo (jpg, jpeg, png)" value="" onchange="return fileValidation(this.id,'previewImg')">
				                  <span class="star">Note:Upload photo (jpg, jpeg, png)</span>                  
				                  <img id="previewImg" alt="Uploaded Image Preview" width="100px" height="100px" style="display: none;" />                  
				                </div>					 						
						</div>
						<div class="row pt-2">
							 <div class="col-md-6">
                			<input type="button" name="Back" value="Cancel" class="btn btn-danger float-left" onclick="location.href = 'manageEmployee.php'">
                		</div>
                		<div class="col-md-6">
              				<input type="submit" name="submit" id="submit" value="submit" class="btn btn-primary float-right">
              			  	</div>
						</div>					 
					</form>

					
				</div>
				<!-- Default Basic Forms End -->

				
			</div>
			
		</div>
	</div>
	<!-- Footer -->
	<?php include "includes/footer.php"; ?>

	<script type="text/javascript" src="js/withGoods.js">
   
</script>