<?php include "includes/header.php";

$parking_data = "select * from parking order by id desc";
$parking_result = $crud->getData($parking_data);
// print_r($parking_result);
// exit;

 ?>

<body>
	

	<?php include "includes/navbar.php"; ?>

	
<?php include "includes/sidebar.php"; ?>
	
	<div class="mobile-menu-overlay"></div>

	<div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-9 col-sm-12">
							<div class="title">
								<h4>DataTable</h4>
							</div>
							
						</div>
						<div class="col-md-3 col-sm-12 text-right">
						<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="#">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">DataTable</li>
								</ol>
							</nav>	
						</div>
					</div>
				</div>
				<!-- Simple Datatable start -->
				<div class="card-box mb-30">

					<div class="pd-20 ">
						<div class="row">
							<div class="col-md-10">
						<h4 class="text-blue h4">Data Table Simple</h4>
						</div>
						<div class="col-md-2">
						<!-- <button type="button" ></button> -->
						<a href="parking.php" class="btn btn-primary ">Add</a>
						</div>
						</div>
						<!-- <p class="mb-0">you can find more options <a class="text-primary" href="https://datatables.net/" target="_blank">Click Here</a></p> -->
					</div>
					<!-- <div class="pb-20"> -->
						<div class = "card-body">
                        <div class = row>
                          <div class = "col-12 table-responsive">
						<table class="data-table table stripe hover nowrap" width="100%" align="center" id="Form_Table">
							<thead>
								<tr>
									<th >S.No</th>
									<th class="table-plus datatable-nosort">Document No</th>
									<th>Department</th>
									<!-- <th>Gate Entry</th> -->
									<th>Gate In Date</th>
									<th>Gate Out Date</th>
									<th>Get Status</th>
									<th>Vehicle image</th>
									
									<th class="datatable-nosort">Action</th>
								</tr>
							</thead>
							
						</table>
					</div>
				</div>
			</div>
		</div>
				<!-- Simple Datatable End -->
				<!-- multiple select row Datatable start -->
				
				<!-- multiple select row Datatable End -->
				<!-- Checkbox select Datatable start -->
				
				<!-- Checkbox select Datatable End -->
				<!-- Export Datatable start -->
				
				<!-- Export Datatable End -->
			</div>
			<?php include "includes/footer.php"; ?>

		</div>
	</div>
	<!-- js -->
	

	<script type="text/javascript" src="js/manageparking.js"></script>
