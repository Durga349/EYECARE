<?php
	 include_once("crudop/crud.php");
    $crud = new Crud();
    session_start();
     

    $document_no  = isset($_POST['document_no']) ? trim($_POST['document_no']): '';

    $department  = isset($_POST['department']) ? trim($_POST['department']) : '';

    $flow_classify  = isset($_POST['flow_classify']) ? trim($_POST['flow_classify']) : '';

    $gate_ent_type  = isset($_POST['gate_ent_type']) ? trim($_POST['gate_ent_type']) : '';

    $weighment_type  = isset($_POST['weighment_type']) ? trim($_POST['weighment_type']) : '';

    $material_trans  = isset($_POST['material_trans']) ? trim($_POST['material_trans']) : '';

    $agent  = isset($_POST['agent']) ? trim($_POST['agent']) : '';

    $weighment_req  = isset($_POST['weighment_req']) ? trim($_POST['weighment_req']) : '';

    $vendor_name  = isset($_POST['vendor_name']) ? trim($_POST['vendor_name']) : '';

    $gate_in_date  = isset($_POST['gate_in_date']) ? trim($_POST['gate_in_date']) : '';

    $gate_out_date    = isset($_POST['gate_out_date']) ? trim($_POST['gate_out_date']) : '';

    $gate_status  = isset($_POST['gate_status']) ? trim($_POST['gate_status']) : '';

    $narration  = isset($_POST['narration']) ? trim($_POST['narration']) : '';

    $date  = isset($_POST['date']) ? trim($_POST['date']) : '';

    $gate  = isset($_POST['gate']) ? trim($_POST['gate']) : '';

    $weigh_bridge  = isset($_POST['weigh_bridge']) ? trim($_POST['weigh_bridge']) : '';

    $weighing_type  = isset($_POST['weighing_type']) ? trim($_POST['weighing_type']) : '';

    $material_type  = isset($_POST['material_type']) ? trim($_POST['material_type']) : '';

    $vehicle  = isset($_POST['vehicle']) ? trim($_POST['vehicle']): '';

    $outside_vehi  = isset($_POST['outside_vehi']) ? trim($_POST['outside_vehi']) : '';

    $ven_name_village  = isset($_POST['ven_name_village']) ? trim($_POST['ven_name_village']) : '';

    $gate_in_time  = isset($_POST['gate_in_time']) ? trim($_POST['gate_in_time']) : '';

    $gate_out_time  = isset($_POST['gate_out_time']) ? trim($_POST['gate_out_time']) : '';

    $scanner_time  = isset($_POST['scanner_time']) ? trim($_POST['scanner_time']) : '';

    $bill_ref_no  = isset($_POST['bill_ref_no']) ? trim($_POST['bill_ref_no']) : '';

    $bill_date  = isset($_POST['bill_date']) ? trim($_POST['bill_date']) : '';

    $bill_date_ref  = isset($_POST['bill_date_ref']) ? trim($_POST['bill_date_ref']) : '';

    $staff_name  = isset($_POST['staff_name']) ? trim($_POST['staff_name']) : '';

    $visitor_name  = isset($_POST['visitor_name']) ? trim($_POST['visitor_name']) : '';

    $randomId       = substr(uniqid(), 0,10);

    $hdn_id         = isset($_POST['hdn_id']) ? $_POST['hdn_id'] : ''; 

   // $hdn_id1         = isset($_POST['hdn_id1']) ? $_POST['hdn_id1'] : '';
    

    $vehi_photo= '';
   
   
    $image_targetDir = "pictures/";

    if(isset($_FILES['vehi_photo'])){
         $imagefileName = basename($_FILES["vehi_photo"]["name"]);
         $targetimageFilePath = $image_targetDir . "vehi_photo_".$randomId.".jpg";
               //exit;
            if(move_uploaded_file($_FILES["vehi_photo"]["tmp_name"], $targetimageFilePath)){                                                              
           $vehi_photo = $targetimageFilePath;
           // echo $image;
           // exit;
         }
       }
       else{         
        $vehi_photo =isset($_POST['edit_extimage']) ? $_POST['edit_extimage'] :'';
      }

    

     if (isset($_POST['action']) && $_POST['action'] == 'save_for_goods'){   
        
         $ins_for_sql = "insert into for_goods set document_no='".$document_no."',
        department='".$department."',
        flow_classify='".$flow_classify."',
        gate_ent_type='".$gate_ent_type."',
        weighment_type='".$weighment_type."',
        material_trans='".$material_trans."',
        agent='".$agent."',
        weighment_req='".$weighment_req."',
        vendor_name='".$vendor_name."',
        gate_in_date='".$gate_in_date."',
        gate_out_date='".$gate_out_date."',
        gate_status='".$gate_status."',
        narration='".$narration."',
        date  ='".$date."',
        gate='".$gate."', 
        weigh_bridge='".$weigh_bridge."',
        weighing_type='".$weighing_type."',
        material_type='".$material_type."',
        vehicle='".$vehicle."',
        outside_vehi='".$outside_vehi."',
        ven_name_village='".$ven_name_village."',
        gate_in_time='".$gate_in_time."',
        gate_out_time='".$gate_out_time."',
        scanner_time='".$scanner_time."',
        vehi_photo='".$vehi_photo."',
        randomId='".$randomId."'";
        //exit;
    
        $res_for_data = $crud->execute($ins_for_sql);        
        if ($res_for_data){
   		echo "true";
     }else{
     	echo "false";
     }
 }

 if (isset($_POST['action']) && $_POST['action'] == 'save_with_goods'){   
        
        $ins_with_sql = "insert into with_goods set document_no='".$document_no."',
        department='".$department."',
        flow_classify='".$flow_classify."',
        gate_ent_type='".$gate_ent_type."',
        weighment_type='".$weighment_type."',
        material_trans='".$material_trans."',
        agent='".$agent."',
        weighment_req='".$weighment_req."',
        vendor_name='".$vendor_name."',
        gate_in_date='".$gate_in_date."',
        gate_out_date='".$gate_out_date."',
        bill_ref_no='".$bill_ref_no."',
        gate_status='".$gate_status."',
        narration='".$narration."',
        date  ='".$date."',
        gate='".$gate."', 
        weigh_bridge='".$weigh_bridge."',
        weighing_type='".$weighing_type."',
        material_type='".$material_type."',
        vehicle='".$vehicle."',
        outside_vehi='".$outside_vehi."',
        ven_name_village='".$ven_name_village."',
        gate_in_time='".$gate_in_time."',
        gate_out_time='".$gate_out_time."',
        bill_date='".$bill_date."',
        bill_date_ref='".$bill_date_ref."',
        scanner_time='".$scanner_time."',
        vehi_photo='".$vehi_photo."',
        randomId='".$randomId."'";
        //exit;
    
        $res_with_data = $crud->execute($ins_with_sql);
        
        if ($res_with_data){
      echo "true";
     }else{
      echo "false";
     }
 }



  if (isset($_POST['action']) && $_POST['action'] == 'for_goods_show'){          
     
  $formshow_forgoods = "select * from for_goods order by id desc";  
// exit;
   
        $formshow_data_forgoods = $crud->getData($formshow_forgoods);       

       $response = array(
        "draw" => 1,
        "recordsTotal" => count($formshow_data_forgoods),
        "data" => $formshow_data_forgoods
    );
    echo json_encode($response);
 }


 if (isset($_POST['action']) && $_POST['action'] == 'with_goods_show'){          
     
  $formshow_withgoods = "select * from with_goods order by id desc";  
// exit;
   
        $formshow_data_withgoods = $crud->getData($formshow_withgoods);       

       $response = array(
        "draw" => 1,
        "recordsTotal" => count($formshow_data_withgoods),
        "data" => $formshow_data_withgoods
    );
    echo json_encode($response);
 }

  if (isset($_POST['action']) && $_POST['action'] == 'delete_for_Goods'){
     
   $delete_forgoods = "delete from for_goods where id='".$_POST['id']."'";
   // exit;
  $delete_data_forgoods = $crud->execute($delete_forgoods);
    if ($delete_data_forgoods){
       echo "true";
     }else{
       echo "false";
     }
 }

 if (isset($_POST['action']) && $_POST['action'] == 'delete_with_Goods'){
     
   $delete_withgoods = "delete from with_goods where id='".$_POST['id']."'";
   // exit;
  $delete_data_withgoods = $crud->execute($delete_withgoods);
    if ($delete_data_withgoods){
       echo "true";
     }else{
       echo "false";
     }
 }



if (isset($_POST['action']) && $_POST['action'] == 'update_for_goods'){   
        
          $upd_for_sql = "update for_goods set document_no='".$document_no."',
        department='".$department."',
        flow_classify='".$flow_classify."',
        gate_ent_type='".$gate_ent_type."',
        weighment_type='".$weighment_type."',
        material_trans='".$material_trans."',
        agent='".$agent."',
        weighment_req='".$weighment_req."',
        vendor_name='".$vendor_name."',
        gate_in_date='".$gate_in_date."',
        gate_out_date='".$gate_out_date."',
        gate_status='".$gate_status."',
        narration='".$narration."',
        date  ='".$date."',
        gate='".$gate."', 
        weigh_bridge='".$weigh_bridge."',
        weighing_type='".$weighing_type."',
        material_type='".$material_type."',
        vehicle='".$vehicle."',
        outside_vehi='".$outside_vehi."',
        ven_name_village='".$ven_name_village."',
        gate_in_time='".$gate_in_time."',
        gate_out_time='".$gate_out_time."',
        scanner_time='".$scanner_time."',
        vehi_photo='".$vehi_photo."' where randomId='".$hdn_id."'";
        //exit;
    
        $upd_for_data = $crud->execute($upd_for_sql);        
        if ($upd_for_data){
        echo "true";
     }else{
        echo "false";
     }
 }

 if (isset($_POST['action']) && $_POST['action'] == 'update_with_goods'){   
        
         $upd_with_sql = "update with_goods set document_no='".$document_no."',
        department='".$department."',
        flow_classify='".$flow_classify."',
        gate_ent_type='".$gate_ent_type."',
        weighment_type='".$weighment_type."',
        material_trans='".$material_trans."',
        agent='".$agent."',
        weighment_req='".$weighment_req."',
        vendor_name='".$vendor_name."',
        gate_in_date='".$gate_in_date."',
        gate_out_date='".$gate_out_date."',
        bill_ref_no='".$bill_ref_no."',
        gate_status='".$gate_status."',
        narration='".$narration."',
        date  ='".$date."',
        gate='".$gate."', 
        weigh_bridge='".$weigh_bridge."',
        weighing_type='".$weighing_type."',
        material_type='".$material_type."',
        vehicle='".$vehicle."',
        outside_vehi='".$outside_vehi."',
        ven_name_village='".$ven_name_village."',
        gate_in_time='".$gate_in_time."',
        gate_out_time='".$gate_out_time."',
        bill_date='".$bill_date."',
        bill_date_ref='".$bill_date_ref."',
        scanner_time='".$scanner_time."',
        vehi_photo='".$vehi_photo."' where randomId='".$_POST['hdn_id']."'";
        //exit;
    
        $upd_with_data = $crud->execute($upd_with_sql);
        
        if ($upd_with_data){
      echo "true";
     }else{
      echo "false";
     }
 }


 if (isset($_POST['action']) && $_POST['action'] == 'dropdown_save'){    
         
       $dropdown_ins = "insert into dropdown_lists set document_no='".$document_no."', 
        department      ='".$department."',       
        flow_classify   = '".$flow_classify."',  
        gate_ent_type   ='".$gate_ent_type."',    
        weighment_type  = '".$weighment_type."', 
        weighment_req   = '".$weighment_req."', 
        weigh_bridge    = '".$weigh_bridge."',         
        weighing_type   = '".$weighing_type."', 
        material_trans  = '".$material_trans."', 
        material_type   = '".$material_type."',   
        gate_status     = '".$gate_status."', 
        gate            = '".$gate."',    
        vendor_name     ='".$vendor_name."', 
        ven_name_village='".$ven_name_village."', 
        staff_name      ='".$staff_name."', 
        visitor_name    ='".$visitor_name."',                 
        agent           ='".$agent."', 
        vehicle         ='".$vehicle."',                
        randomId        ='".$randomId."'";         
     
        $dropdown_data = $crud->execute($dropdown_ins); 
         
        if ($dropdown_data){ 
        echo "true"; 
     }else{ 
        echo "false"; 
     } 
 }


 if (isset($_POST['action']) && $_POST['action'] == 'dropdown_show'){ 
         
      
 $visitor_show = "select * from dropdown_lists order by id desc";   
 //exit; 
    
        $visitor_data = $crud->getData($visitor_show);        
 
       $response = array( 
        "draw" => 1, 
        "recordsTotal" => count($visitor_data), 
        "data" => $visitor_data 
    ); 
 
    echo json_encode($response); 
 }


 if (isset($_POST['action']) && $_POST['action'] == 'dropdown_update'){    
         
        $dropdown_ins = "update dropdown_lists set document_no='".$document_no."', 
        department      ='".$department."',       
        flow_classify   = '".$flow_classify."',  
        gate_ent_type   ='".$gate_ent_type."',    
        weighment_type  = '".$weighment_type."', 
        weighment_req   = '".$weighment_req."', 
        weigh_bridge    = '".$weigh_bridge."',         
        weighing_type   = '".$weighing_type."', 
        material_trans  = '".$material_trans."', 
        material_type   = '".$material_type."',   
        gate_status     = '".$gate_status."', 
        gate            = '".$gate."',    
        vendor_name     ='".$vendor_name."', 
        ven_name_village='".$ven_name_village."', 
        staff_name      ='".$staff_name."', 
        visitor_name    ='".$visitor_name."',                 
        agent           ='".$agent."', 
        vehicle         ='".$vehicle."' where randomId='".$_POST['hdn_id']."'";

        //exit;         
     
        $dropdown_data = $crud->execute($dropdown_ins); 
         
        if ($dropdown_data){ 
        echo "true"; 
     }else{ 
        echo "false"; 
     } 
 }

 if (isset($_POST['action']) && $_POST['action'] == 'delete_drop'){
     
   $delete_drop = "delete from dropdown_lists where id='".$_POST['id']."'";
   // exit;
  $delete_dropData = $crud->execute($delete_drop);
    if ($delete_dropData){
       echo "true";
     }else{
       echo "false";
     }
 }


 if (isset($_POST['action']) && $_POST['action'] == 'save'){   
        
          $ins_sql = "insert into parking set 
        document_no='".$document_no."',
        department='".$department."',
        gate_ent_type='".$gate_ent_type."',
        gate_in_date='".$gate_in_date."',
        gate_out_date='".$gate_out_date."',
        gate_status='".$gate_status."',
        date='".$date."',
        narration='".$narration."',
        gate='".$gate."',
        vehicle='".$vehicle."',
        gate_in_time='".$gate_in_time."',
        gate_out_time='".$gate_out_time."',
        vehi_photo='".$vehi_photo."',
        randomId='".$randomId."'";
        //exit;
    
        $res_data = $crud->execute($ins_sql);
        
        if ($res_data){
        echo "true";
     }else{
        echo "false";
     }
 }

 if (isset($_POST['action']) && $_POST['action'] == 'show'){
         extract($_POST);
     
  $formshow = "select * from  parking order by id asc";  
// exit;
   
        $formshow_data = $crud->getData($formshow);       

       $response = array(
        "draw" => 1,
        "recordsTotal" => count($formshow_data),
        "data" => $formshow_data
    );

    echo json_encode($response);
 }

 if (isset($_POST['action']) && $_POST['action'] == 'update'){   
        
          $upd_sql = "update parking set 
        document_no='".$document_no."',
        department='".$department."',
        gate_ent_type='".$gate_ent_type."',
        gate_in_date='".$gate_in_date."',
        gate_out_date='".$gate_out_date."',
        gate_status='".$gate_status."',
        date='".$date."',
        narration='".$narration."',
        gate='".$gate."',
        vehicle='".$vehicle."',
        gate_in_time='".$gate_in_time."',
        gate_out_time='".$gate_out_time."',
        vehi_photo='".$vehi_photo."' where randomId='".$_POST['hdn_id']."'";
        //exit;
    
        $upd_data = $crud->execute($upd_sql);
        
        if ($upd_data){
        echo "true";
     }else{
        echo "false";
     }
 }

 if (isset($_POST['action']) && $_POST['action'] == 'delete'){
     
   $delete = "delete from parking where id='".$_POST['id']."'";
   // exit;
  $delete_data = $crud->execute($delete);
    if ($delete_data){
       echo "true";
     }else{
       echo "false";
     }
 }




 
 


 // if (isset($_POST['action']) && $_POST['action'] == 'statusyes'){

     
 //            $formstatus = "update  addform set status='".$_POST['status']."' where id='".$_POST['id']."'";
 //        //exit;
 //        $formstatus_data = $crud->execute($formstatus);
 //       if ($formstatus_data){
 //   		echo "true";
 //     }else{
 //     	echo "false";
 //     }


 // }

  
?>