<?php include "includes/header.php"; 

?>


  <?php include "includes/navbar.php"; ?>

  <?php include "includes/sidebar.php"; ?>
  
<style>
    .error{
      color: red;
    }
  </style>

  <div class="mobile-menu-overlay"></div>

  <div class="main-container">
    <div class="pd-ltr-20 xs-pd-20-10">
      <div class="min-height-200px">
        <div class="page-header">
          <div class="row">
            <div class="col-md-9 col-sm-12">
              <div class="title">
                <h4>Dropdowns Data</h4>
              </div>
              
            </div>
          <div class="col-md-3 col-sm-12">
              <nav aria-label="breadcrumb" role="navigation">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Dropdowns Data</li>
                </ol>
              </nav>
            </div>
          </div>
        </div>
        <!-- Default Basic Forms Start -->
        <div class="pd-20 card-box mb-30">
          <div class="clearfix">
            <div class="pull-left">
              <h4 class="text-blue h4">Add Dropdowns</h4><br>
              <!-- <p class="mb-30">All bootstrap element classies</p> -->
            </div>
            
          </div>
          <form method="post" name="addform" id="addform" enctype="multipart/form-data"  autocomplete="off">
            
              <div class="row">
                <div class="col-md-6">
                  <label>Document No.</label>  
                 <input type="text" name="document_no" id="document_no" class="form-control">
                </div>
                
              <div class="col-md-6">
                  <label>Department</label>
                <input type="text" name="department" id="department" class="form-control">
                </div>
            </div>
            
            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Flow Classify</label>
                   <input type="text" name="flow_classify" id="flow_classify" class="form-control">
                </div>
            
                <div class="col-md-6">
                  <label>Gate Entry Type</label>
                  <input type="text" name="gate_ent_type" id="gate_ent_type" class="form-control">
                </div>
            </div>

            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Weighment Type</label>
                   <input type="text" name="weighment_type" id="weighment_type" class="form-control">
                </div>

                <div class="col-md-6">
                  <label>Weighment Requirement</label>
                   <input type="text" name="weighment_req" id="weighment_req" class="form-control">
                </div>
            </div>


            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Weigh Bridge</label>
                   
                   <input type="text" name="weigh_bridge" id="weigh_bridge" class="form-control">
                </div>
                <div class="col-md-6">
                  <label>Weigh Type</label>
                  <input type="text" name="weighing_type" id="weighing_type" class="form-control">
                </div> 
              </div>

            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Material Transaction</label>
                  <input type="text" name="material_trans" id="material_trans" class="form-control">
                </div> 
                <div class="col-md-6">
                  <label>Material Type</label>
                   <input type="text" name="material_type" id="material_type" class="form-control">
                </div>                           
            </div>


            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Gate Status</label>
                   <input type="text" name="gate_status" id="gate_status" class="form-control">
                  
                </div>
            <div class="col-md-6">
                  <label>Gate</label>
                   <input type="text" name="gate" id="gate" class="form-control">
                </div>                
            </div>

            <div class="row pt-2">
              <div class="col-md-6">
                  <label>Vendor Name</label>
                   <input type="text" name="vendor_name" id="vendor_name" class="form-control">
                </div> 
                
            <div class="col-md-6">
                  <label>Vendor Village Name</label>
                   <input type="text" name="ven_name_village" id="ven_name_village" class="form-control">
                </div>
                
              
            </div>            
            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Satff Name</label>
                  <input type="text" name="staff_name" id="staff_name" class="form-control">
                </div>
                <div class="col-md-6">
                  <label>Visitor Name</label>
                  <input type="text" name="visitor_name" id="visitor_name" class="form-control">
                </div>
              </div>

              <div class="row pt-2">
                <div class="col-md-6">
                  <label>Agent</label>
                   <input type="text" name="agent" id="agent" class="form-control">
                </div> 
                <div class="col-md-6">
                  <label>Vehicle</label>
                  <input type="text" name="vehicle" id="vehicle" class="form-control">
                </div>
              </div>

              <div class="row pt-3">
                <div class="col-md-6">
                <input type="button" name="cancel" value="Cancel" class="btn btn-danger" onclick="window.location = 'manageDropdowns.php'" style="float: left;">
              </div>
              <div class="col-md-6">
              <input type="submit" name="submit" value="Submit" class="btn btn-primary" style="float: right;">
            </div>
              </div>
          </form>
          
        </div>
        <!-- Default Basic Forms End -->

        
      </div>
      
    </div>
  </div>
  <!-- Footer -->
      <?php include "includes/footer.php"; ?>

<script type="text/javascript" src="js/add_Dropdowns.js">
   
</script>