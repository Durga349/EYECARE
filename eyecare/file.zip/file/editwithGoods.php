<?php include "includes/header.php";

$doc_sql = "select * from dropdown_lists order by id asc";
$doc_data = $crud->getData($doc_sql); 

 $randid = $_GET['randomId'];
 $sel_qry = "select * from with_goods where randomId = '".$randid."' ";
 $res_data = $crud->getData($sel_qry);

?>


  <?php include "includes/navbar.php"; ?>

  <?php include "includes/sidebar.php"; ?>
  
<style>
    .error{
      color: red;
    }
  </style>

  <div class="mobile-menu-overlay"></div>

  <div class="main-container">
    <div class="pd-ltr-20 xs-pd-20-10">
      <div class="min-height-200px">
        <div class="page-header">
          <div class="row">
            <div class="col-md-9 col-sm-12">
              <div class="title">
                <?php if($_REQUEST['type'] == 'view' ){ ?>
                <h4>View Form For Goods</h4>
                <?php } ?>
              </div>
              
            </div>
          <div class="col-md-3 col-sm-12">
              <nav aria-label="breadcrumb" role="navigation">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                  <?php if($_REQUEST['type'] == 'view' ){ ?>
                  <li class="breadcrumb-item active" aria-current="page">View Form For Goods</li>
                <?php } ?>
                </ol>
              </nav>
            </div>
          </div>
        </div>
        <!-- Default Basic Forms Start -->
        <div class="pd-20 card-box mb-30">
          <div class="clearfix">
            <div class="pull-left">

            	<?php if($_REQUEST['type']=='edit'){?>
                <h5 style="line-height: 20px;" class="card-title p-2">Edit Form With Goods</h5>
                  <?php }?>

               <?php if($_REQUEST['type'] == 'view' ){ ?>
              <h4 class="text-blue h4">View Form With Goods</h4>
              <?php } ?><br>
              <!-- <p class="mb-30">All bootstrap element classies</p> -->
            </div>
            
          </div>
<?php if($_REQUEST['type']=='view'){?>
          <form method="post" name="addform" id="addform" enctype="multipart/form-data"  autocomplete="off">
							<div class="row">
								<div class="col-md-6">
									<label>Document No.</label>
									<input type="text" name="document_no" class="form-control" value="<?php echo $res_data[0]['document_no'] ?>" readonly>							
								</div>
								
						
								<div class="col-md-6">
									<label>Department</label>
									<input type="text" name="department" class="form-control" value="<?php echo $res_data[0]['department'] ?>" readonly>										
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Flow Calssify</label>
									<input type="text" name="flow_classify" class="form-control" value="<?php echo $res_data[0]['flow_classify'] ?>" readonly>													
								</div>
								
						
								<div class="col-md-6">
									<label>Gate Entry Type</label>
									<input type="text" name="gate_ent_type" class="form-control" value="<?php echo $res_data[0]['gate_ent_type'] ?>" readonly>
																	
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Weighment Type</label>
									<input type="text" name="weighment_type" class="form-control" value="<?php echo $res_data[0]['weighment_type'] ?>" readonly>
																		
								</div>
								
						
								<div class="col-md-6">
									<label>Material Transaction</label>
									<input type="text" name="material_trans" class="form-control" value="<?php echo $res_data[0]['material_trans'] ?>" readonly>
																	
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Agent</label>
									<input type="text" name="agent" class="form-control" value="<?php echo $res_data[0]['agent'] ?>" readonly>
																	
								</div>
								
						
								<div class="col-md-6">
									<label>Is Weighment Required</label>
									<input type="text" name="weighment_req" class="form-control" value="<?php echo $res_data[0]['weighment_req'] ?>" readonly>
																		
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Vendor Name</label>
									<input type="text" name="vendor_name" class="form-control" value="<?php echo $res_data[0]['vendor_name'] ?>" readonly>
																	
								</div>

								<div class="col-md-6">
									<label>Gate Status</label>
									<input type="text" name="gate_status" class="form-control" value="<?php echo $res_data[0]['gate_status'] ?>" readonly>
																		
								</div>
								
						
														
						</div>

						<div class="row pt-2">
							<div class="col-md-6">
									<label>Gate In Date</label>
									<input type="text" name="gate_in_date" id="gate_in_date" class="form-control" value="<?php echo $res_data[0]['gate_in_date'] ?>" readonly>			
								</div>
								<div class="col-md-6">
									<label>Gate Out Date</label>
									<input type="text" name="gate_out_date" id="gate_out_date" class="form-control" value="<?php echo $res_data[0]['gate_out_date'] ?>" readonly>			
								</div>
								
						
														
						</div>

						<div class="row pt-2">
									<div class="col-md-6">
									<label>Bill Reference No.</label>
									<input type="text" name="bill_ref_no" id="bill_ref_no" class="form-control" value="<?php echo $res_data[0]['bill_ref_no'] ?>" readonly>						
								</div>						
								<div class="col-md-6">
									<label>Date</label>
									<input type="text" name="date" id="date" class="form-control" value="<?php echo $res_data[0]['date'] ?>" readonly>								
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Gate</label>
									<input type="text" name="gate" class="form-control" value="<?php echo $res_data[0]['gate'] ?>" readonly>
																	
								</div>
								
						
								<div class="col-md-6">
									<label>Weigh Bridge</label>
									<input type="text" name="weigh_bridge" class="form-control" value="<?php echo $res_data[0]['weigh_bridge'] ?>" readonly>
																	
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Weighing Type</label>
									<input type="text" name="weighing_type" class="form-control" value="<?php echo $res_data[0]['weighing_type'] ?>" readonly>
																		
								</div>
								
						 
								<div class="col-md-6">
									<label>Material Type</label>
									<input type="text" name="material_type" class="form-control" value="<?php echo $res_data[0]['material_type'] ?>" readonly>
																	
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Vehicle</label>
									<input type="text" name="vehicle" class="form-control" value="<?php echo $res_data[0]['vehicle'] ?>" readonly>																
								</div>
								
						
								<div class="col-md-6">
									<label>Outside Vehicle</label>
									<input type="text" name="outside_vehi" id="outside_vehi" class="form-control" value="<?php echo $res_data[0]['outside_vehi'] ?>" readonly>				
								</div>						
						</div>

						<div class="row pt-2">					
								<div class="col-md-6">
									<label>Gate In</label>
									<input type="text" name="gate_in_time" id="gate_in_time" class="form-control" value="<?php echo $res_data[0]['gate_in_time'] ?>" readonly>				
								</div>	

								<div class="col-md-6">
									<label>Gate Out</label>
									<input type="text" name="gate_out_time" id="gate_out_time" class="form-control" value="<?php echo $res_data[0]['gate_out_time'] ?>" readonly>			
								</div>					
						</div>

						<div class="row pt-2">						
								<div class="col-md-6">
									<label>Scanner Time</label>
									<input type="text" name="scanner_time" id="scanner_time" class="form-control" value="<?php echo $res_data[0]['scanner_time'] ?>" readonly>				
								</div>	

								<div class="col-md-6">
									<label>Vendor Name in Village</label>
									<input type="text" name="ven_name_village" class="form-control" value="<?php echo $res_data[0]['ven_name_village'] ?>" readonly>
																		
								</div>					
						</div>

						<div class="row pt-2">

							<div class="col-md-6">
									<label>Bill Date</label>
									<input type="date" name="bill_date" id="bill_date" class="form-control" value="<?php echo $res_data[0]['bill_date'] ?>" readonly>							
								</div>

								<div class="col-md-6">
									<label>Bill Reference No.</label>
									<input type="text" name="bill_date_ref" id="bill_date_ref" class="form-control" value="<?php echo $res_data[0]['bill_date_ref'] ?>" readonly>							
								</div>					 						
						</div>

						<div class="row pt-2">
							<div class="col-md-6">
									<label>Narration</label>
									<input type="text" name="narration" class="form-control" value="<?php echo $res_data[0]['narration'] ?>" readonly>
																
								</div>

								<div class="col-md-6">              
				                <label  for="exampleInputEmail1">Vehicle Photo
				                  <!-- <span class="star">*</span> --></label>
				                  <img id="previewImg" alt="Uploaded Image Preview" width="90px;" height="80px;"  style="display: none;"/>
                   				 <img src="<?php echo $res_data[0]['vehi_photo'];?>" width="100px;" height="100px;">                  
				                </div>					 						
						</div>
						<div class="row pt-2">
							 <div class="col-md-6">
                			<input type="button" name="Back" value="Cancel" class="btn btn-danger float-left" onclick="location.href = 'managewithGoods.php'">
                		</div>
                		<!-- <div class="col-md-6">
              				<input type="submit" name="submit" value="submit" class="btn btn-primary float-right">
              			  	</div> -->
						</div>					 
					</form>
<?php } ?>  

<?php if($_REQUEST['type']=='edit'){?>
	<form method="post" name="withGoods" id="withGoods" enctype="multipart/form-data"  autocomplete="off">
							<div class="row">
								<div class="col-md-6">
									<label>Document No.</label>
									<select name="document_no" id="document_no" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	
										 <option value="<?php echo $value['id']?>" <?php if($value['id'] == $res_data[0]['document_no']){echo "selected";}?>><?php echo $value['document_no']?></option>
										 <?php }?>		
									</select>									
								</div>
								
						
								<div class="col-md-6">
									<label>Department</label>
									<select name="department" id="department" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	
										 <option value="<?php echo $value['id']?>" <?php if($value['id'] == $res_data[0]['department']){echo "selected";}?>><?php echo $value['department']?></option>
										 <?php }?>	
									</select>									
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Flow Calssify</label>
									<select name="flow_classify" id="flow_classify" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	
										 <option value="<?php echo $value['id']?>" <?php if($value['id'] == $res_data[0]['flow_classify']){echo "selected";}?>><?php echo $value['flow_classify']?></option>
										 <?php }?>		
									</select>									
								</div>
								
						
								<div class="col-md-6">
									<label>Gate Entry Type</label>
									<select name="gate_ent_type" id="gate_ent_type" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	
										 <option value="<?php echo $value['id']?>" <?php if($value['id'] == $res_data[0]['gate_ent_type']){echo "selected";}?>><?php echo $value['gate_ent_type']?></option>
										 <?php }?>	
									</select>									
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Weighment Type</label>
									<select name="weighment_type" id="weighment_type" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	
										 <option value="<?php echo $value['id']?>" <?php if($value['id'] == $res_data[0]['weighment_type']){echo "selected";}?>><?php echo $value['weighment_type']?></option>
										 <?php }?>		
									</select>									
								</div>
								
						
								<div class="col-md-6">
									<label>Material Transaction</label>
									<select name="material_trans" id="material_trans" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	
										 <option value="<?php echo $value['id']?>" <?php if($value['id'] == $res_data[0]['material_trans']){echo "selected";}?>><?php echo $value['material_trans']?></option>
										 <?php }?>	
									</select>									
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Agent</label>
									<select name="agent" id="agent" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	
										 <option value="<?php echo $value['id']?>" <?php if($value['id'] == $res_data[0]['agent']){echo "selected";}?>><?php echo $value['agent']?></option>	
										 <?php }?>
									</select>									
								</div>
								
						
								<div class="col-md-6">
									<label>Is Weighment Required</label>
									<select name="weighment_req" id="weighment_req" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	
										 <option value="<?php echo $value['id']?>" <?php if($value['id'] == $res_data[0]['weighment_req']){echo "selected";}?>><?php echo $value['weighment_req']?></option>
										 <?php }?>	
									</select>									
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Vendor Name</label>
									<select name="vendor_name" id="vendor_name" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	
										 <option value="<?php echo $value['id']?>" <?php if($value['id'] == $res_data[0]['vendor_name']){echo "selected";}?>><?php echo $value['vendor_name']?></option>
										 <?php }?>	
									</select>									
								</div>

								

								<div class="col-md-6">
									<label>Gate Status</label>
									<select name="gate_status" id="gate_status" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	
										 <option value="<?php echo $value['id']?>" <?php if($value['id'] == $res_data[0]['gate_status']){echo "selected";}?>><?php echo $value['gate_status']?></option>
										 <?php }?>
									</select>									
								</div>
								
						
														
						</div>

						<div class="row pt-2">

							<div class="col-md-6">
									<label>Gate In Date</label>
									<input type="date" name="gate_in_date" id="gate_in_date" class="form-control" value="<?php echo $res_data[0]['gate_in_date'] ?>">			
								</div>
								<div class="col-md-6">
									<label>Gate Out Date</label>
									<input type="date" name="gate_out_date" id="gate_out_date" class="form-control" value="<?php echo $res_data[0]['gate_out_date'] ?>">			
								</div>												
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Bill Reference No.</label>
									<input type="text" name="bill_ref_no" id="bill_ref_no" class="form-control" value="<?php echo $res_data[0]['bill_ref_no'] ?>">						
								</div>
								
						
								<div class="col-md-6">
									<label>Date</label>
									<input type="date" name="date" id="date" class="form-control" value="<?php echo $res_data[0]['date'] ?>">								
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Gate</label>
									<select name="gate" id="gate" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	
										 <option value="<?php echo $value['id']?>" <?php if($value['id'] == $res_data[0]['gate']){echo "selected";}?>><?php echo $value['gate']?></option>	
										<?php }?>	
									</select>									
								</div>
								
						
								<div class="col-md-6">
									<label>Weigh Bridge</label>
									<select name="weigh_bridge" id="weigh_bridge" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	
										 <option value="<?php echo $value['id']?>" <?php if($value['id'] == $res_data[0]['weigh_bridge']){echo "selected";}?>><?php echo $value['weigh_bridge']?></option>
										<?php }?>	
									</select>									
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Weighing Type</label>
									<select name="weighing_type" id="weighing_type" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	
										 <option value="<?php echo $value['id']?>" <?php if($value['id'] == $res_data[0]['weighing_type']){echo "selected";}?>><?php echo $value['weighing_type']?></option>
										<?php }?>
									</select>									
								</div>
								
						
								<div class="col-md-6">
									<label>Material Type</label>
									<select name="material_type" id="material_type" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	
										 <option value="<?php echo $value['id']?>" <?php if($value['id'] == $res_data[0]['material_type']){echo "selected";}?>><?php echo $value['material_type']?></option>	
										<?php }?>	
									</select>									
								</div>						
						</div>

						<div class="row pt-2">
								<div class="col-md-6">
									<label>Vehicle</label>
									<select name="vehicle" id="vehicle" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	
										 <option value="<?php echo $value['id']?>" <?php if($value['id'] == $res_data[0]['vehicle']){echo "selected";}?>><?php echo $value['vehicle']?></option>
										<?php }?>	
									</select>									
								</div>
								
						
								<div class="col-md-6">
									<label>Outside Vehicle</label>
									<input type="text" name="outside_vehi" id="outside_vehi" class="form-control" value="<?php echo $res_data[0]['outside_vehi'] ?>">				
								</div>						
						</div>

						<div class="row pt-2">						
						
								<div class="col-md-6">
									<label>Gate In</label>
									<input type="time" name="gate_in_time" id="gate_in_time" class="form-control" value="<?php echo $res_data[0]['gate_in_time'] ?>">				
								</div>	

								<div class="col-md-6">
									<label>Gate Out</label>
									<input type="time" name="gate_out_time" id="gate_out_time" class="form-control" value="<?php echo $res_data[0]['gate_out_time'] ?>">			
								</div>					
						</div>

						<div class="row pt-2">					
								
						
								<div class="col-md-6">
									<label>Scanner Time</label>
									<input type="time" name="scanner_time" id="scanner_time" class="form-control" value="<?php echo $res_data[0]['scanner_time'] ?>">				
								</div>	

								<div class="col-md-6">
									<label>Vendor Name in Village</label>
									<select name="ven_name_village" id="ven_name_village" class="form-control">
										<option value="">--select--</option>
										<?php foreach($doc_data as $value){ ?>	
										 <option value="<?php echo $value['id']?>" <?php if($value['id'] == $res_data[0]['ven_name_village']){echo "selected";}?>><?php echo $value['ven_name_village']?></option>
										<?php }?>	
									</select>									
								</div>					
						</div>

						<div class="row pt-2">

							<div class="col-md-6">
									<label>Bill Date</label>
									<input type="date" name="bill_date" id="bill_date" class="form-control" value="<?php echo $res_data[0]['bill_date'] ?>">							
								</div>

								<div class="col-md-6">
									<label>Bill Reference No.</label>
									<input type="text" name="bill_date_ref" id="bill_date_ref" class="form-control" value="<?php echo $res_data[0]['bill_date_ref'] ?>">							
								</div>					 						
						</div>

						<div class="row pt-2">

							<div class="col-md-6">
									<label>Narration</label>
									<textarea name="narration" id="narration" class="form-control"><?php echo $res_data[0]['narration'] ?></textarea>							
								</div>

								<div class="col-md-6">              
				                <label  for="exampleInputEmail1">Vehicle Photo
				                  <!-- <span class="star">*</span> --></label>
				                  <input type="hidden" id="edit_extimage" name="edit_extimage" class="form-control" value="<?php echo $res_data[0]['vehi_photo'];?>">
				                  <input type="file" class="form-control" name="vehi_photo" id="vehi_photo" title="Please upload photo (jpg, jpeg, png)" value="" onchange="return fileValidation(this.id,'previewImg')">
				                 <img src="<?php echo $res_data[0]['vehi_photo'];?>" width="100px;" height="100px;">
				                    <img id="previewImg" alt="Upload Image Preview" width="90px" height="80px" style="display: none;"/>                      
				                </div>					 						
						</div>
						<div class="row pt-2">
							 <div class="col-md-6">
							 	<input type="hidden" name="hdn_id" id="hdn_id" value="<?php echo $res_data[0]['randomId'] ?>">
                			<input type="button" name="Back" value="Cancel" class="btn btn-danger float-left" onclick="location.href = 'managewithGoods.php'">
                		</div>
                		<div class="col-md-6">
              				<input type="submit" name="update" id="update" value="update" class="btn btn-primary float-right">
              			  	</div>
						</div>					 
					</form>
<?php } ?>
          
        </div>
        <!-- Default Basic Forms End -->

        
      </div>
      
    </div>
  </div>
  <!-- Footer -->
      <?php include "includes/footer.php"; ?>

<script type="text/javascript" src="js/editwithGoods.js">
   
</script>