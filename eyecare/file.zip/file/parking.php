<?php include "includes/header.php";
$doc_sql = "select * from dropdown_lists order by id asc";
$doc_data = $crud->getData($doc_sql);

?>


<style type="text/css">document
	.error{
		color: red;
	}
</style>

	<?php include "includes/navbar.php"; ?>

	<?php include "includes/sidebar.php"; ?>
	


	<div class="mobile-menu-overlay"></div>

	<div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-9 col-sm-12">
							<div class="title">
								<h4>Parking Form</h4>
							</div>
							
						</div>
					<div class="col-md-3 col-sm-12">
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.html">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Parking Form</li>
								</ol>
							</nav>
						</div>
					</div>
				</div>
				<!-- Default Basic Forms Start -->
				<div class="pd-20 card-box mb-30">
					<div class="clearfix">
						<div class="pull-left">
							<h4 class="text-blue h4">Parking Form</h4><br>
							<!-- <p class="mb-30">All bootstrap element classies</p> -->
						</div>
						
					</div>
					<form method="post" id="addformpage" name="addformpage" enctype="multipart/form-data">
						
							<div class="row">
								<div class="col-md-6">
									<label>Document No</label>
									<select   class="custom-select col-12" name="document_no" id="document_no" class="form-control">
									
									<option value="">--Select--</option>
										<?php foreach ($doc_data as $value) { ?>
									<option value="<?php echo $value['id']; ?>"><?php echo $value['document_no']; ?></option>
										<?php } ?>
								</select>
									
								</div>						
								<div class="col-md-6">
									<label>Department</label>	
								<select class="custom-select col-12" name="department" id="department" class="form-control">
									<option value="">--Select--</option>
									<?php foreach ($doc_data as $key => $value) { ?>

										<option value="<?php echo $value['id']; ?>"><?php echo $value['department']; ?></option>
										
									<?php } ?>
									
									
								</select>
									
								</div>				
						</div>						
						<div class="row pt-2">
								<div class="col-md-6">
									<label>Gate Entry Type 	</label>
									<select class="custom-select col-12" name="gate_ent_type" id="gate_ent_type" class="form-control">
									<option value="">--Select--</option>
									<?php foreach ($doc_data as $key => $value) { ?>
											<option value="<?php echo $value['id']; ?>"><?php echo $value['gate_ent_type']; ?></option>
									<?php } ?>
								
									
								</select>
									
								</div>

								<div class="col-md-6">
									<label>Gate In Date	</label>
									<input type="date" name="gate_in_date" id="gate_in_date" class="form-control">
									
								</div>							
						</div>
						<div class="row pt-2">
								<div class="col-md-6">
									<label>Gate Out Date</label>
									<input type="date" name="gate_out_date" id="gate_out_date" class="form-control">
								</div>						
								<div class="col-md-6">
									<label>Gate Status</label>
									<select class="custom-select col-12" name="gate_status" id="gate_status" class="form-control">
									<option value="">--Select--</option>
									<?php foreach ($doc_data as $key => $value) { ?>
									<option value="<?php echo $value['id']; ?>"><?php echo $value['gate_status']; ?></option>
								
									<?php } ?>
							
									
								</select>
									
								</div>			
						</div>
						<div class="row pt-2">
														
								<div class="col-md-6">
									<label>Date</label>
									<input type="date" name="date" id="date" class="form-control">
								</div>			
						</div>
						<div class="row pt-2">
								<div class="col-md-6">
									<label>Gate</label>
									<select class="custom-select col-12" name="gate" id="gate" class="form-control">
									<option value="">--Select--</option>
									<?php foreach ($doc_data as $key => $value) { ?>

										<option value="<?php echo $value['id'] ?>"><?php echo $value['gate'] ?></option>

									<?php } ?>

									</select>
									
					
								</div>						
								<div class="col-md-6">
									<label>Vehicle</label>
									<select class="custom-select col-12" name="vehicle" id="vehicle" class="form-control">
									<option value="">--Select--</option>
									<?php foreach ($doc_data as $key => $value) { ?>

										<option value="<?php echo $value['id'] ?>"><?php echo $value['vehicle'] ?></option>
									
										
									<?php } ?>
									
								</select>
								</div>			
						</div>	
						<div class="row pt-2">
								<div class="col-md-6">
									<label>GateIn</label>
									<input type="time" name="gate_in_time" id="gate_in_time" class="form-control">
								</div>						
								<div class="col-md-6">
									<label>Gateout</label>
									<input type="time" name="gate_out_time" id="gate_out_time" class="form-control">
								</div>			
						</div>		
						<div class="row pt-2">
							<div class="col-md-6">
									<label>Narration</label>
									
									<textarea class="form-control" name="narration" id="narration"></textarea>
								</div>
								<!-- <div class="col-md-6">
									<label>VehiclePhoto</label>
									<input type="file" name="vehiclePhoto" id="vehiclePhoto" class="form-control">
								</div>
 -->
									<div class="col-md-6">               
                    <label  for="exampleInputEmail1">Vehicle Photo 
                      <!-- <span class="star">*</span> --></label> 
                      <input type="file" class="form-control" name="vehi_photo" id="vehi_photo" title="Please upload photo (jpg, jpeg, png)" value="" onchange="return fileValidation(this.id,'previewImg')"> 
                      <span class="star">Note:Upload photo (jpg, jpeg, png)</span>                   
                      <img id="previewImg" alt="Uploaded Image Preview" width="100px" height="100px" style="display: none;" />                   
                    </div>

											
						</div>
						<div class="row pt-2">
							<div class="col-md-12">
							<input type="button" name="cancel" id="cancel" class="btn btn-danger float-left" value="Cancel" onclick="location.href = 'manageparking.php'">
							<input type="submit" name="submit" id="submit" class="btn btn-primary float-right" value="Submit">
							</div>
						</div>
						
						
					</form>
					
				</div>
				<!-- Default Basic Forms End -->

				
			</div>
			
		</div>
	</div>
	<!-- Footer -->
<?php include "includes/footer.php"; ?>

  <script type="text/javascript" src="js/parking.js"></script>

  </body>
</html>
