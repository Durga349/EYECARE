<?php include "includes/header.php"; 

 $randid = $_GET['randomId'];
 $sel_qry = "select * from dropdown_lists where randomId = '".$randid."' ";
//exit;
 $res_data = $crud->getData($sel_qry);

?>


  <?php include "includes/navbar.php"; ?>

  <?php include "includes/sidebar.php"; ?>
  
<style>
    .error{
      color: red;
    }
  </style>

  <div class="mobile-menu-overlay"></div>

  <div class="main-container">
    <div class="pd-ltr-20 xs-pd-20-10">
      <div class="min-height-200px">
        <div class="page-header">
          <div class="row">
            <div class="col-md-9 col-sm-12">
              <div class="title">
                <?php if($_REQUEST['type'] == 'view' ){ ?>
                <h4>View Drop Down</h4>
                <?php } ?>
              </div>
              
            </div>
          <div class="col-md-3 col-sm-12">
              <nav aria-label="breadcrumb" role="navigation">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                  <?php if($_REQUEST['type'] == 'view' ){ ?>
                  <li class="breadcrumb-item active" aria-current="page">View Drop Down</li>
                <?php } ?>
                </ol>
              </nav>
            </div>
          </div>
        </div>
        <!-- Default Basic Forms Start -->
        <div class="pd-20 card-box mb-30">
          <div class="clearfix">
            <div class="pull-left">
            	 <?php if($_REQUEST['type']=='edit'){?>
                <h5 style="line-height: 20px;" class="card-title p-2">Edit Drop Down</h5>
                  <?php }?>

               <?php if($_REQUEST['type'] == 'view' ){ ?>
              <h4 class="text-blue h4">View Drop Down</h4>
              <?php } ?><br>
              <!-- <p class="mb-30">All bootstrap element classies</p> -->
            </div>
            
          </div>

 <?php if($_REQUEST['type']=='view'){?>

          <form method="post" name="addform" id="addform" enctype="multipart/form-data"  autocomplete="off" readonly>
            
              <div class="row">
                <div class="col-md-6">
                  <label>Document No.</label>  
                 <input type="text" name="document_no" id="document_no" class="form-control" value="<?php echo $res_data[0]['document_no'] ?>" readonly>
                </div>
                
              <div class="col-md-6">
                  <label>Department</label>
                <input type="text" name="department" id="department" class="form-control" value="<?php echo $res_data[0]['department'] ?>" readonly>
                </div>
            </div>
            
            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Flow Classify</label>
                   <input type="text" name="flow_classify" id="flow_classify" class="form-control" value="<?php echo $res_data[0]['flow_classify'] ?>" readonly>
                </div>
            
                <div class="col-md-6">
                  <label>Gate Entry Type</label>
                  <input type="text" name="gate_ent_type" id="gate_ent_type" class="form-control" value="<?php echo $res_data[0]['gate_ent_type'] ?>" readonly>
                </div>
            </div>

            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Weighment Type</label>
                   <input type="text" name="weighment_type" id="weighment_type" class="form-control" value="<?php echo $res_data[0]['weighment_type'] ?>" readonly>
                </div>

                <div class="col-md-6">
                  <label>Weighment Requirement</label>
                   <input type="text" name="weighment_req" id="weighment_req" class="form-control" value="<?php echo $res_data[0]['weighment_req'] ?>" readonly>
                </div>
            </div>


            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Weigh Bridge</label>
                   
                   <input type="text" name="weigh_bridge" id="weigh_bridge" class="form-control" value="<?php echo $res_data[0]['weigh_bridge'] ?>" readonly>
                </div>
                <div class="col-md-6">
                  <label>Weigh Type</label>
                  <input type="text" name="weighing_type" id="weighing_type" class="form-control" value="<?php echo $res_data[0]['weighing_type'] ?>" readonly>
                </div> 
              </div>

            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Material Transaction</label>
                  <input type="text" name="material_trans" id="material_trans" class="form-control" value="<?php echo $res_data[0]['material_trans'] ?>" readonly>
                </div> 
                <div class="col-md-6">
                  <label>Material Type</label>
                   <input type="text" name="material_type" id="material_type" class="form-control" value="<?php echo $res_data[0]['material_type'] ?>" readonly>
                </div>                           
            </div>


            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Gate Status</label>
                   <input type="text" name="gate_status" id="gate_status" class="form-control" value="<?php echo $res_data[0]['gate_status'] ?>" readonly>
                  
                </div>
            <div class="col-md-6">
                  <label>Gate</label>
                   <input type="text" name="gate" id="gate" class="form-control" value="<?php echo $res_data[0]['gate'] ?>" readonly>
                </div>                
            </div>

            <div class="row pt-2">
              <div class="col-md-6">
                  <label>Vendor Name</label>
                   <input type="text" name="vendor_name" id="vendor_name" class="form-control" value="<?php echo $res_data[0]['vendor_name'] ?>" readonly>
                </div> 
                
            <div class="col-md-6">
                  <label>Vendor Village Name</label>
                   <input type="text" name="ven_name_village" id="ven_name_village" class="form-control" value="<?php echo $res_data[0]['ven_name_village'] ?>" readonly>
                </div>
                
              
            </div>            
            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Satff Name</label>
                  <input type="text" name="staff_name" id="staff_name" class="form-control" value="<?php echo $res_data[0]['staff_name'] ?>" readonly>
                </div>
                <div class="col-md-6">
                  <label>Visitor Name</label>
                  <input type="text" name="visitor_name" id="visitor_name" class="form-control" value="<?php echo $res_data[0]['visitor_name'] ?>" readonly>
                </div>
              </div>

              <div class="row pt-2">
                <div class="col-md-6">
                  <label>Agent</label>
                   <input type="text" name="agent" id="agent" class="form-control" value="<?php echo $res_data[0]['agent'] ?>" readonly>
                </div> 
                <div class="col-md-6">
                  <label>Vehicle</label>
                  <input type="text" name="vehicle" id="vehicle" class="form-control" value="<?php echo $res_data[0]['vehicle'] ?>" readonly>
                </div>
              </div>

              <div class="row pt-3">
                <div class="col-md-6">
                <input type="button" name="cancel" value="Cancel" class="btn btn-danger" onclick="window.location = 'manageDropdown.php'" style="float: left;">
              </div>
              
              </div>
          </form>
<?php } ?>  

<?php if($_REQUEST['type']=='edit'){?>

<form method="post" name="addform" id="addform" enctype="multipart/form-data"  autocomplete="off">
            
              <div class="row">
                <div class="col-md-6">
                  <label>Document No.</label>  
                 <input type="text" name="document_no" id="document_no" class="form-control" value="<?php echo $res_data[0]['document_no'] ?>">
                </div>
                
              <div class="col-md-6">
                  <label>Department</label>
                <input type="text" name="department" id="department" class="form-control" value="<?php echo $res_data[0]['department'] ?>">
                </div>
            </div>
            
            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Flow Classify</label>
                   <input type="text" name="flow_classify" id="flow_classify" class="form-control" value="<?php echo $res_data[0]['flow_classify'] ?>">
                </div>
            
                <div class="col-md-6">
                  <label>Gate Entry Type</label>
                  <input type="text" name="gate_ent_type" id="gate_ent_type" class="form-control" value="<?php echo $res_data[0]['gate_ent_type'] ?>">
                </div>
            </div>

            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Weighment Type</label>
                   <input type="text" name="weighment_type" id="weighment_type" class="form-control" value="<?php echo $res_data[0]['weighment_type'] ?>">
                </div>

                <div class="col-md-6">
                  <label>Weighment Requirement</label>
                   <input type="text" name="weighment_req" id="weighment_req" class="form-control" value="<?php echo $res_data[0]['weighment_req'] ?>">
                </div>
            </div>


            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Weigh Bridge</label>
                   
                   <input type="text" name="weigh_bridge" id="weigh_bridge" class="form-control" value="<?php echo $res_data[0]['weigh_bridge'] ?>">
                </div>
                <div class="col-md-6">
                  <label>Weigh Type</label>
                  <input type="text" name="weighing_type" id="weighing_type" class="form-control" value="<?php echo $res_data[0]['weighing_type'] ?>">
                </div> 
              </div>

            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Material Transaction</label>
                  <input type="text" name="material_trans" id="material_trans" class="form-control" value="<?php echo $res_data[0]['material_trans'] ?>">
                </div> 
                <div class="col-md-6">
                  <label>Material Type</label>
                   <input type="text" name="material_type" id="material_type" class="form-control" value="<?php echo $res_data[0]['material_type'] ?>">
                </div>                           
            </div>


            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Gate Status</label>
                   <input type="text" name="gate_status" id="gate_status" class="form-control" value="<?php echo $res_data[0]['gate_status'] ?>">
                  
                </div>
            <div class="col-md-6">
                  <label>Gate</label>
                   <input type="text" name="gate" id="gate" class="form-control" value="<?php echo $res_data[0]['gate'] ?>">
                </div>                
            </div>

            <div class="row pt-2">
              <div class="col-md-6">
                  <label>Vendor Name</label>
                   <input type="text" name="vendor_name" id="vendor_name" class="form-control" value="<?php echo $res_data[0]['vendor_name'] ?>">
                </div> 
                
            <div class="col-md-6">
                  <label>Vendor Village Name</label>
                   <input type="text" name="ven_name_village" id="ven_name_village" class="form-control" value="<?php echo $res_data[0]['ven_name_village'] ?>">
                </div>
                
              
            </div>            
            <div class="row pt-2">
                <div class="col-md-6">
                  <label>Satff Name</label>
                  <input type="text" name="staff_name" id="staff_name" class="form-control" value="<?php echo $res_data[0]['staff_name'] ?>">
                </div>
                <div class="col-md-6">
                  <label>Visitor Name</label>
                  <input type="text" name="visitor_name" id="visitor_name" class="form-control" value="<?php echo $res_data[0]['visitor_name'] ?>">
                </div>
              </div>

              <div class="row pt-2">
                <div class="col-md-6">
                  <label>Agent</label>
                   <input type="text" name="agent" id="agent" class="form-control" value="<?php echo $res_data[0]['agent'] ?>">
                </div> 
                <div class="col-md-6">
                  <label>Vehicle</label>
                  <input type="text" name="vehicle" id="vehicle" class="form-control" value="<?php echo $res_data[0]['vehicle'] ?>">
                </div>
              </div>

              <div class="row pt-3">
                <div class="col-md-6">
                	<input type="hidden" name="hdn_id" value="<?php echo $randid; ?>">

                <input type="button" name="cancel" value="Cancel" class="btn btn-danger" onclick="window.location = 'manageDropdowns.php'" style="float: left;">
              </div>

              <div class="col-md-6">
              <input type="submit" name="submit" value="Upddate" class="btn btn-primary" style="float: right;">
            </div>
              
              </div>
          </form> 
<?php } ?>       
        </div>
        <!-- Default Basic Forms End -->

        
      </div>
      
    </div>
  </div>
  <!-- Footer -->
      <?php include "includes/footer.php"; ?>

<script type="text/javascript" src="js/editDropdown.js">
   
</script>